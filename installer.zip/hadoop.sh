#Script for hadoop

TAR=~/hadoop-2.8.5.tar.gz
if [ ! -f "$TAR" ]; then
	wget https://archive.apache.org/dist/hadoop/common/hadoop-2.8.5/hadoop-2.8.5.tar.gz
else
	echo "INFO: tar already existst."
fi

FILE=~/hadoop
if [ ! -d "$FILE" ]; then
	tar xf hadoop-2.8.5.tar.gz

	mkdir -p hadoop/hdfs/namenode

	mkdir -p hadoop/hdfs/datanode

	mkdir -p hadoop/temp/hadooptmpdata

	mv hadoop-2.8.5 hadoop/
else
	echo "INFO: file already exists."
fi

if grep -q HADOOP  ~/.bashrc
then 
	echo "INFO: .bashrc already modified.";
else
	cat tem/hadoop >> .bashrc
fi

cat tem/core-site.xml > hadoop/hadoop-2.8.5/etc/hadoop/core-site.xml

cat tem/hdfs-site.xml > hadoop/hadoop-2.8.5/etc/hadoop/hdfs-site.xml

cp  hadoop/hadoop-2.8.5/etc/hadoop/mapred-site.xml.template hadoop/hadoop-2.8.5/etc/hadoop/mapred-site.xml

cat tem/mapred-site.xml > hadoop/hadoop-2.8.5/etc/hadoop/mapred-site.xml

cat tem/yarn-site.xml > hadoop/hadoop-2.8.5/etc/hadoop/yarn-site.xml

read -p "Modify hadoop-env.sh and press any key..."

hdfs namenode -format

start-dfs.sh

start-yarn.sh

jps

hdfs dfs -mkdir /test

hdfs dfs -ls /

stop-yarn.sh

stop-dfs.sh

#Script for hive

TAR=~/apache-hive-2.3.6-bin.tar.gz
if [ ! -f "$TAR" ]; then
	wget http://apache-mirror.rbc.ru/pub/apache/hive/stable-2/apache-hive-2.3.6-bin.tar.gz

else
	echo "INFO: tar already existst."
fi

FILE=~/hive
if [ ! -d "$FILE" ]; then
	tar xf apache-hive-2.3.6-bin.tar.gz 

	mkdir hive

	mv apache-hive-2.3.6-bin hive/
else
	echo "INFO: file already exists."
fi

if grep -q HIVE  ~/.bashrc
then 
	echo "INFO: .bashrc already modified.";
else
	cat tem/hive >> .bashrc
	source .bashrc
fi

cp hive/apache-hive-2.3.6-bin/conf/hive-env.sh.template hive/apache-hive-2.3.6-bin/conf/hive-env.sh

cat tem/hive-env.sh > hive/apache-hive-2.3.6-bin/conf/hive-env.sh

cp hive/apache-hive-2.3.6-bin/conf/hive-default.xml.template hive/apache-hive-2.3.6-bin/conf/hive-site.xml

cat tem/hive-site.xml > hive/apache-hive-2.3.6-bin/conf/hive-site.xml

hdfs dfs -mkdir -p /user/hive/warehouse

hdfs dfs -mkdir /tmp

hdfs dfs -chmod g+w /user/hive/warehouse

hdfs dfs -chmod g+w /tmp

schematool -initSchema -dbType derby

start-dfs.sh

start-yarn.sh

hive

#Script for spark

TAR=~/spark-3.0.0-preview2-bin-hadoop2.7.tgz
if [ ! -f "$TAR" ]; then
        wget  http://mirror.linux-ia64.org/apache/spark/spark-3.0.0-preview2/spark-3.0.0-preview2-bin-hadoop2.7.tgz
else
        echo "INFO: tar already existst."
fi

FILE=~/spark
if [ ! -d "$FILE" ]; then
        tar xf spark-3.0.0-preview2-bin-hadoop2.7.tgz 

        mkdir spark

        mv spark-3.0.0-preview2-bin-hadoop2.7 spark/
else
        echo "INFO: file already exists."
fi

if grep -q SPARK  ~/.bashrc
then 
        echo "INFO: .bashrc already modified.";
else
        cat tem/spark >> .bashrc
        source .bashrc
fi

